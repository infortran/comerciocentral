﻿using System;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using AplicacionPrueba.Servicio;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

namespace AplicacionPrueba
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.lblStatus.Text = "Inicializada";
            this.dataGridView1.Visible = false;

            ServicePointManager.ServerCertificateValidationCallback = delegate(
                Object obj, X509Certificate certificate, X509Chain chain,
                SslPolicyErrors errors)
            {
                return (true);
            };
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {


            using (SieteWS sieteWS = new SieteWS())
            {
                string usuario = this.txtUsuario.Text;
                string password = this.txtClave.Text;

                this.txtMensajesError.Text = string.Empty;

                lblStatus.Text = "Inicio llamado obtención series para frecuencia " + this.txtFrequency.Text;

                Respuesta respuesta = sieteWS.SearchSeries(usuario, password, this.txtFrequency.Text);

                if (respuesta.Codigo == 0)
                {

                    lblStatus.Text = "Éxito: " + respuesta.SeriesInfos.FirstOrDefault().englishTitle +
                                     ". Se encontraron " + respuesta.SeriesInfos.Length + " series";

                    this.dataGridView1.Visible = true;
                    BindingSource b = new BindingSource();
                    b.DataSource =
                        respuesta.SeriesInfos.Select(
                            x =>
                            new
                                {
                                    SerieId = x.seriesId,
                                    Nombre = x.firstObservation,
                                    Adicional = x.lastObservation,
                                    Titulo = x.spanishTitle
                                });
                    this.dataGridView1.DataSource = b;
                }
                else
                {
                    this.txtMensajesError.Text = "Error :" + respuesta.Descripcion;
                }
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            using (SieteWS sieteWS = new SieteWS())
            {
                string usuario = this.txtUsuario.Text;
                string password = this.txtClave.Text;


                //this.txtRespuesta2.Text = string.Empty;

                string[] series =
                    this.txtSeries.Text.Replace(" ", "").Split(";".ToCharArray()).Where(x => x.Length > 0).ToArray();

                lblStatus.Text = "Inicio llamado con " + series.Length + " serie(s)";

                Respuesta respuesta = sieteWS.GetSeries(usuario, password, this.txtFechaInicio.Text,
                                                            this.txtFechaTermino.Text, series);

                if (respuesta.Codigo == 0)
                {
                    //lblStatus.Text = DateTime.Now.ToLongTimeString() + " OK " + respuesta.SeriesInfos.FirstOrDefault().englishTitle;

                    lblStatus.Text = "Éxito. Se encontraron " + respuesta.Series.Length + " datos";
                    flowLayoutPanel1.Controls.Clear();
                    flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;
                    flowLayoutPanel1.WrapContents = false;

                    foreach (fameSeries fameSeries in respuesta.Series)
                    {
                        DataGridView dd = new DataGridView();
                        Label la = new Label();
                        la.Text = (fameSeries.seriesKey.seriesId);
                        if (fameSeries.obs != null)
                        {

                            var listado =
                                fameSeries.obs.Select(x => new {Fecha = x.indexDateString, Valor = x.value}).ToList();
                            BindingSource b = new BindingSource();
                            b.DataSource = listado;
                            dd.DataSource = b;
                            flowLayoutPanel1.Controls.Add(la);
                            dd.AutoGenerateColumns = true;
                            dd.AutoSize = true;
                            dd.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                            dd.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCells);
                            flowLayoutPanel1.Controls.Add(dd);
                            //        foreach (var obs in fameSeries.obs)
                            //      {
                            //        this.txtRespuesta2.Text += obs.indexDateString + " " + obs.value + Environment.NewLine;
                            //  }
                        }
                    }
                }
                else
                {
                    this.txtMensajesError.Text = "Error :" + respuesta.Descripcion;
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {

            var estacorrecto = dataGridView1.Rows[e.RowIndex].Cells[0] as DataGridViewCheckBoxCell;

            bool co = bool.Parse(estacorrecto.EditingCellFormattedValue.ToString());

            dataGridView1.Rows[e.RowIndex].Selected = false;

            dataGridView1.Rows[e.RowIndex].Cells[0].Value = false;
            if (co)
            {
                dataGridView1.Rows[e.RowIndex].Cells[0].Value = true;
                dataGridView1.Rows[e.RowIndex].Selected = true;
            }
            RevisaCelda();

        }


        private void RevisaCelda()
        {
            this.txtSeries.Text = "";
            foreach (DataGridViewRow fila in dataGridView1.Rows)
            {

                var val1 = fila.Cells[0].Value;
                if (val1 != null && val1.ToString().ToLower() == "true")
                {
                    var val2 = fila.Cells[1].Value.ToString().Trim();
                    this.txtSeries.Text += val2 + @";";

                }

            }
        }

    }
}